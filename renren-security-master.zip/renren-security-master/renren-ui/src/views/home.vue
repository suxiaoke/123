<template>
  <el-card shadow="never" class="aui-card--fill">
    <div class="mod-home">
      <h3>项目介绍</h3>
      <ul>
        <li>renren-security是一个轻量级的，前后端分离的Java快速开发平台，能快速开发项目并交付【接私活利器】</li>
        <li>采用SpringBoot、Shiro、MyBatis-Plus框架，开发的一套权限系统，极低门槛，拿来即用。设计之初，就非常注重安全性，为企业系统保驾护航，让一切都变得如此简单</li>
        <li>提供了代码生成器，只需编写30%左右代码，其余的代码交给系统自动生成，可快速完成开发任务</li>
        <li>支持MySQL、达梦、Oracle、SQL Server、PostgreSQL等主流数据库</li>
        <li>前后端分离，通过token进行数据交互，可独立部署</li>
        <li>动态菜单，通过菜单管理统一管理访问路由</li>
        <li>演示地址：<a href="http://demo.open.renren.io/renren-security" target="_blank">http://demo.open.renren.io/renren-security</a> (账号密码：admin/admin)</li>
      </ul>
      <h3>获取帮助</h3>
      <ul>
        <li>官方社区：<a href="https://www.renren.io/community" target="_blank">https://www.renren.io/community</a></li>
        <li>Git地址：<a href="https://gitee.com/renrenio/renren-security" target="_blank">https://gitee.com/renrenio/renren-security</a></li>
        <li>如需关注项目最新动态，请Watch、Star项目，同时也是对项目最好的支持</li>
      </ul>
    </div>
  </el-card>
</template>

<style scoped>
.mod-home {
  line-height: 1.5;
}
</style>
<script setup lang="ts"></script>
