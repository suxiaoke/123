import { withInstall } from "@/utils/utils";
import RenSelect from "./src/ren-select.vue";

export default withInstall(RenSelect);
