import mitt, { Emitter } from "mitt";

/**
 * 事件总线
 */
export default mitt() as Emitter;
