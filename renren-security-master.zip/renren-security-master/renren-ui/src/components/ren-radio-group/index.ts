import { withInstall } from "@/utils/utils";
import RenRadioGroup from "./src/ren-radio-group.vue";

export default withInstall(RenRadioGroup);
