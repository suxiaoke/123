import { withInstall } from "@/utils/utils";
import RenDeptTree from "./src/ren-dept-tree.vue";

RenDeptTree.name = "RenDeptTree";
export default withInstall(RenDeptTree);
