interface ImportMetaEnv {
  /**
   * api接口环境
   */
  VITE_APP_API: string;
}
