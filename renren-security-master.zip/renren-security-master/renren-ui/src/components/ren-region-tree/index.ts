import { withInstall } from "@/utils/utils";
import RenRegionTree from "./src/ren-region-tree.vue";

RenRegionTree.name = "RenRegionTree";
export default withInstall(RenRegionTree);
