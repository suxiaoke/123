declare interface Window {
  axios: any;
}
