import { withInstall } from "@/utils/utils";
import SvgIcon from "./index.vue";

export default withInstall(SvgIcon);
